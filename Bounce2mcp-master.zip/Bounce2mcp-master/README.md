Bounce 2 for Adafruit MCP23017 Library
=======

This is a fork of the Bounce2 Debouncing library for Arduino or Wiring by Thomas Ouellet Fredericks that is designed to work with buttons that are attached to a MCP23017 GPIO port expander. 

I have made one other small modification to the Bounce2 library, and that is to include the interval_millis setting in the initial attach declaration.

Enjoy!

Here is the original Library: https://github.com/thomasfredericks/Bounce2


Have a Question?
========

Post your question here: https://forums.adafruit.com/viewtopic.php?p=349792